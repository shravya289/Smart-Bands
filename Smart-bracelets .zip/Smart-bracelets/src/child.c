#include "contiki.h"
#define PRELOADED_KEY ";c{?K|JNy?3)'D2KJ+%7"
#include "smart-bracelet.h"


AUTOSTART_PROCESSES(&Child_bracelet_process);


