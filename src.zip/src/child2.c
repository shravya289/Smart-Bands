#include "contiki.h"
#define PRELOADED_KEY "M6#Bhe5nD&Thrht59U7u"
#include "smart-bracelet.h"


AUTOSTART_PROCESSES(&Child_bracelet_process);


