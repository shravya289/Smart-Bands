#include "contiki.h"
#include "smart-bracelet.h"


AUTOSTART_PROCESSES(&key_generation_process);


